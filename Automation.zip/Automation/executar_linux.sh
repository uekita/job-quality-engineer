#!/bin/sh

java -jar -Xms1024m -Xmx2048m automation.jar